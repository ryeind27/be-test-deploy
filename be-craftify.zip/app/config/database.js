module.exports = {
    url: "mongodb+srv://craftify:nI23ZijHMk2qUcEC@craftify.fwpsz0u.mongodb.net/?retryWrites=true&w=majority"
}